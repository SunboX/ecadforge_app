var path = require ('path');
var createSharedStaticServer = require ('../static_server.js').createStaticServer;

var DefaultRoute = '/examples/esp12_viewer/';

function createStaticServer (options)
{
    options = options || {};
    return createSharedStaticServer ({
        rootDir : options.rootDir || path.resolve (__dirname, '../..'),
        defaultRoute : options.defaultRoute || DefaultRoute
    });
}

if (require.main === module) {
    var port = Number (process.env.PORT || 8090);
    var host = process.env.HOST || '127.0.0.1';
    var server = createStaticServer ();
    server.listen (port, host, function () {
        var address = 'http://' + host + ':' + port + DefaultRoute;
        console.log ('Serving ESP_12 viewer at ' + address);
    });
}

module.exports = {
    createStaticServer : createStaticServer
};
